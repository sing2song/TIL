from django.db import models

# Table이 class형태로 구현이 되기 때문에 여기서 만든다.
# 이 파일은 모델을 정의하는 파일이다.
# 따라서 우리는 Question, Choice 두 개의 테이블을 만들면 된다.
# 그리고 Table의 column들은 속성으로 표현한다!!

class Question(models.Model):
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')

    def __str__(self):
        return self.question_text

class Choice(models.Model):
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)

    def __str__(self):
        return self.choice_text
