// JavaScript에 대해서 알아보아요!!
// 1. 변수선언(파이썬이랑 거의 비슷)
let tmp1 = 'sample';    // string
let tmp2 = 3.14;        // number
let tmp3 = true;        // boolean
let tmp4 = [1, 2, 3, 4] // array

// 변수를 출력하고 싶어요!!
// alert(), console.log()
// alert(tmp1)   // blocking method : 여기에서 코드의 수행이 일시 중지
// console.log('변수의 값 : ' + tmp1)

// javascript 객체 ( python의 dict와 같은 구조 => 데이터 표현방식으로는 JSON )
// let obj = { name : '홍길동',
//             age : 25 }
//
// console.log(obj.name)

// 함수를 만들어 보아요!!
// function add(x,y) {
//     return x + y
// }
//
// alert(add(10,20))


