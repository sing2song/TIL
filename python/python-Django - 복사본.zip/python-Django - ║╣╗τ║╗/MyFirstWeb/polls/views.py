from django.shortcuts import render, get_object_or_404
from polls.models import Question, Choice
from django.http import HttpResponseRedirect
from django.urls import reverse

# Create your views here.]
def index(request) :
    #데이터베이스를 뒤져서 설문목록을 가져와요!
    # 테이블명 : polls_question, 클래스명 : Question
    question_list = Question.objects.all().order_by('-pub_date')[:5]
    # 데이터 전달을 dict로 만들어요!
    context = {'q_list':question_list}
    return render(request, 'polls/index.html', context)

def detail(request, question_id):
    # 숫자하나가 question_id로 들어와요! 이 숫자는 question_id, 즉 설문 번호(PK)
    question = get_object_or_404(Question, pk=question_id)
    context = { 'selected_question' : question}
    return render(request, 'polls/detail.html', context)

def vote(request, question_id):
    question = get_object_or_404(Question, pk=question_id) #설문객체 가져옴

    try:
        selected_choice = question.choice_set.get(pk=request.POST['my_choice'])
    # 클라이언트가 보낸 요청 중에 POST형식의 my_choice로 데이터를 가져온다.
    # 이게 POST형식으로 전달하는 방식임.
    except(KeyError, Choice.DoesNotExist):
        # 설문에서 아무것도 선택하지 않았을 때.
        # 즉, PK가 없어서 오류가 발생할 경우
        return render(request, 'polls/detail.html',
                      {'selected_question': question,
                       'error_message': '아무것도 선택하지 않았어요!'})
    else:
        selected_choice.votes += 1
        selected_choice.save()

    return HttpResponseRedirect(reverse('polls:results',
                                        args=(question.id,)))
    # 얘는 클라이언트한테 http대신 url을 보내주는 것임.
    # 그래서 클라이언트는 이 url로 재접속 하는거다.
    # reverse()는 urls.py(URLConf)에 있는 name을 이용해서 url 형식으로 변환

    # context = {'selected_question': question}
    # return render(request, 'polls/detal.html', context)
    # render함수는 HttpResponse() 이거를 만들어서 클라이언트한테 전달

def results(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    return render(request, 'polls/results.html', {
        'question': question
    })