"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

#이제 얘는 polls안에 들어오는 url만 처리한다.

from django.urls import path
from . import views

# http://localhost:8000/polls/

app_name = 'polls'

urlpatterns = [
    path('', views.index, name='index'),

    #polls/1/ 이렇게 들어오면 이게 호출!
    path('<int:question_id>/', views.detail, name='detail'),

    # ~~/polls/1/vote/ 이렇게 들어오면 이게 호출
    path('<int:question_id>/vote/', views.vote, name='vote'),
    # 얘는 나중에 polls:votes 로 표현이 될 것이다.

    path('<int:question_id>/results/', views.results, name='results')
]
